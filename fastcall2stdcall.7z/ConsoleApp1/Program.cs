﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
		[UnmanagedFunctionPointer(CallingConvention.StdCall, CharSet = CharSet.Unicode)]
		private delegate int GetPID2Delegate(IntPtr FileTime, IntPtr MPID, int LangId, int dwBuildNumber, int unk, IntPtr DPID2);

		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate int WrapperGetPID2Delegate(IntPtr functionPtr, IntPtr FileTime, IntPtr MPID, int LangId, int dwBuildNumber, int unk, IntPtr DPID2);

		[DllImport("kernel32.dll")]
		internal static extern bool RtlZeroMemory(IntPtr destination, int length);

		// Token: 0x06000094 RID: 148
		[DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
		internal static extern bool SetDllDirectory(string lpPathName);

		// Token: 0x06000095 RID: 149
		[DllImport("kernel32", SetLastError = true)]
		internal static extern IntPtr LoadLibrary(string lpFileName);

		// Token: 0x06000096 RID: 150
		[DllImport("Kernel32.dll")]
		internal static extern IntPtr GetProcAddress(IntPtr hModule, string lpProcName);

		// Token: 0x06000097 RID: 151
		[DllImport("kernel32.dll")]
		internal static extern bool FreeLibrary(IntPtr hModule);
		static string string_0 = Environment.CurrentDirectory + "\\";
		[UnmanagedFunctionPointer(CallingConvention.StdCall, CharSet = CharSet.Unicode)]
		private delegate int fnPidGenX(string ProuctKey, string PkeyPath, string MPCID, IntPtr UnknownUsage, IntPtr PID2, IntPtr PID3, IntPtr PID4);
		private static IntPtr hModule_base = IntPtr.Zero;
		static void Main(string[] args)
        {
			string ProductKeys = "VK7JG-NPHTM-C97JM-9MPGT-3V66T";
			string text = "";
			string text2 = "-1";
			string text3 = "";
			string text4 = "";
			IntPtr intPtr = Marshal.AllocHGlobal(100);
			RtlZeroMemory(intPtr, 50);
			Marshal.WriteByte(intPtr, 0, 50);
			IntPtr intPtr2 = Marshal.AllocHGlobal(164);
			RtlZeroMemory(intPtr2, 164);
			Marshal.WriteByte(intPtr2, 0, 164);
			IntPtr intPtr3 = Marshal.AllocHGlobal(1272);
			RtlZeroMemory(intPtr3, 1272);
			Marshal.WriteByte(intPtr3, 0, 248);
			Marshal.WriteByte(intPtr3, 1, 4);
			IntPtr hModule = LoadLibrary("ProductKeyUtilities.dll");
			hModule_base = hModule;
			IntPtr procAddress = GetProcAddress(hModule, "PidGenX");
			fnPidGenX delegateForFunctionPointer = Marshal.GetDelegateForFunctionPointer<fnPidGenX>(procAddress);

			//如果要hook该函数
			IntPtr HookPtr = FastCall.WrapStdCallInFastCall(Marshal.GetFunctionPointerForDelegate(new GetPID2Delegate(MyGetPID2)));
			Hook HookFunc = new Hook(new IntPtr(hModule.ToInt32() + 50073), HookPtr);
			Hook.Install();


			text3 = "D:\\Elite\\source\\repos\\PidKey\\PidKey\\bin\\Debug\\pkconfig\\pkconfig_winNext.xrm-ms";
			int num = delegateForFunctionPointer(ProductKeys, text3, "55041", (IntPtr)0, intPtr, intPtr2, intPtr3);
			Console.WriteLine(num.ToString());
			Hook.Unistall();
			Console.ReadLine();
		}

		private static int MyGetPID2(IntPtr intptr_1, IntPtr intptr_2, int int_0, int int_1, int int_2, IntPtr intptr_3)
		{
			Hook.Unistall();
			int num = 0;
			checked
			{
				if (hModule_base != IntPtr.Zero)
				{
					WrapperGetPID2Delegate wrapperGetPID2Delegate = FastCall.StdcallToFastcall<WrapperGetPID2Delegate>(FastCall.InvokePtr);
					num = wrapperGetPID2Delegate(new IntPtr(hModule_base.ToInt32() + 50073), intptr_1, intptr_2, int_0, int_1, int_2, intptr_3);
					Console.WriteLine("num:" + num);
					if (num == 0)
					{
						Marshal.PtrToStringUni(intptr_3);
						object obj2 = Marshal.PtrToStructure(intptr_1, typeof(FileTime));
						FileTime fileTime = (obj2 != null) ? ((FileTime)obj2) : default(FileTime);
						Console.WriteLine(fileTime.ActConfigKey);
					}
				}
				Hook.Install();
				return num;
			}
		}


	}

	[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto, Pack = 4)]
	public struct FileTime
	{
		// Token: 0x0400006D RID: 109
		public int index;

		// Token: 0x0400006E RID: 110
		[MarshalAs(UnmanagedType.LPWStr)]
		public string ActConfigKey;
	}
}
